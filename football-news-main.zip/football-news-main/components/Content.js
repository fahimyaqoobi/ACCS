export default function Content({ children }) {
    return (<div className="content-width page-content">
        {children}
    </div>)
}